<?php
$config['appId']  = '241859905992660';
$config['secret'] = '1ccc21a28143d92c100e38e75a080343';
$config['pageid'] = '8261409764'; //1428715620681598
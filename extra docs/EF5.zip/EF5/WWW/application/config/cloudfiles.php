<?php

/*
 * The Cloudfile username.
 */
$config['cf_user'] = '';

/*
 * The API Key associated to the account.
 */
$config['cf_api_key'] = '';

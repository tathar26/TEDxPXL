<?php
$config['email_contact']  = 'gunther@livezone.be';

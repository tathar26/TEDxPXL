<?php if (!defined('BASEPATH')) die();
class Zoek extends Main_Controller {

   public function index()
	{	
		$this->load->model('zoek_model', 'zoek');
		$query = $this->input->post('search');
		$SiteLoad['return'] = $this->zoek->searchItems($query);
		$SiteLoad['title'] = "Hexion";
		$this->siteload->load('zoek', $SiteLoad);
	}
	   
}

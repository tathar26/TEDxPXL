<?php if (!defined('BASEPATH')) die();
class contact extends Main_Controller {

   public function index()
	{
		$this->load->helper('captcha');
		$SiteLoad['title'] = "Hexion";
		$this->siteload->load('contact', $SiteLoad);
	}

	public function sendemail()
	{
	
  function errorResponse ($messsage) {
    header('HTTP/1.1 500 Internal Server Error');
    die(json_encode(array('message' => $messsage)));
  }


	$this->config->load('contact');

	  header('Content-type: application/json');

	
	  //do Captcha check, make sure the submitter is not a robot:)...
	  include_once $_SERVER['DOCUMENT_ROOT'].'/assets/library/vender/securimage/securimage.php';
	  $securimage = new Securimage();
		  if (!$securimage->check($_POST['captcha_code'])) {
			errorResponse('Invalid Security Code');
		  }else{
			 $this->load->library('email');
		
			$this->email->from($this->input->post('email',TRUE), $this->input->post('name',TRUE));
			$this->email->to($this->config->item('email_contact')); 
			
			$this->email->subject('Hexion Contact');
			$this->email->message("Name: " .$this->input->post('name',TRUE)."\n\n"."Comment:\n" . nl2br($this->input->post('message',TRUE)));	
		
			$this->email->send();
		
  }
	}
}
?>

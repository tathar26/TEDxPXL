<?php if (!defined('BASEPATH')) die();
/**
* @author Gunther Claes <gunther@livezone.be>
*/
class forum extends Main_Controller {

public function index()
{
	$SiteLoad['title'] = "Hexion - Forum";
	
	if($this->ion_auth->logged_in()){
		$SiteLoad['currentUser'] = $this->session->userdata('user_id');
	}else{
		$SiteLoad['currentUser']=0;
	}
	
	if($this->ion_auth->is_admin()){
		$SiteLoad['admin'] = 1;
	}else{
		$SiteLoad['admin'] = 0;
	}
	if($this->uri->segment(2) == null){
		$SiteLoad['current'] = 0;
	}else{
		$SiteLoad['current'] = $this->uri->segment(2);
	}
	$this->siteload->load('forum', $SiteLoad);
}

/** 
* Comment: Item inladen
*/

public function getItems(){
	$this->load->model('Forum_model', 'forum');
	$data['return'] = json_encode($this->forum->getItems());
	$this->load->view('ajax', $data);

}

	/** 
* Comment: Inhoud inladen
*/

public function getContent(){
	if($this->ion_auth->logged_in() && $this->ion_auth->user()->row()->active==1){
		$this->load->model('Forum_model', 'forum');
		$data['return'] = json_encode($this->forum->getContent());
		$this->load->view('ajax', $data);
	}else{
		$error['error'] = "Je heb geen toestemming om deze inhoud te bekijken";
		$data['return'] = json_encode($error);
		$this->load->view('ajax', $data);
	}
}

	/** 
* Comment: nieuwe topic
*/

public function newTopic(){
	if($this->ion_auth->logged_in()){
		$this->load->model('Forum_model', 'forum');
		$content = $this->input->post('content', TRUE);
		$title = $this->input->post('title', TRUE);
		$newId['id'] = $this->forum->newTopic($title, $content);
		$data['return'] = json_encode($newId);
		$this->load->view('ajax', $data);
	}
}

	/** 
* Comment: nieuwe reactie
*/

public function newComment(){
	if($this->ion_auth->logged_in() && $this->input->post('item', TRUE) != 0){
		$this->load->model('Forum_model', 'forum');
		$content = $this->input->post('content', TRUE);
		$item = $this->input->post('item', TRUE);
		$this->forum->newComment($item, $content);
	}
}

	/** 
* Comment: Reactie bewerken
*/
public function editComment(){
	if($this->ion_auth->logged_in()){
		$this->load->model('Forum_model', 'forum');
		$content = $this->input->post('content');
		$item = $this->input->post('itemId');
		$this->forum->editComment($item, $content);
	}
}

	/** 
* Comment: Reactie verwijderen
*/
public function delComment(){
	if($this->ion_auth->logged_in()){
		$item = $this->uri->segment(3);
		$this->load->model('Forum_model', 'forum');
		$this->forum->delComment($item);
	}
}

	/** 
* Comment: Forum doorzoeken
*/
public function searchItems(){
	$query = $this->input->post('search');
	$this->load->model('Forum_model', 'forum');
	$data['return'] = json_encode($this->forum->searchItems($query));
	$this->load->view('ajax', $data);

}



}

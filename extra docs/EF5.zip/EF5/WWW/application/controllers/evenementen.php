<?php if (!defined('BASEPATH')) die();
class evenementen extends Main_Controller {

   public function index()
	{
		$SiteLoad['title'] = "Hexion";
		$this->siteload->load('evenementen', $SiteLoad);
	}
	
	  /**
   * 
   * Comment: Ophalen van evenementen van Facebook
   *
   */
	public function events(){

		$fb_events = $this->fb->sdk->api("/".$this->config->item('pageid')."/events");
		$data['return']['success']=1;
		$data['return']['result'] = array();
		foreach($fb_events['data'] as $event){
			array_push($data['return']['result'], array("id"=>$event['id'],
											'title' => $event['name'], 
											'url' => site_url("evenementen/evenement/".$event['id']),
											'class' => "event-warning",
											'start' => strtotime($event['start_time'])."000",
											'end' => strtotime($event['start_time'])."000"
										));
		}
		
		$data['return'] = json_encode($data['return']);

		$this->load->view('ajax', $data);
	}
	
	/**
   * 
   * Comment: Informatie ophalen voor een bepaald evenement.
   *
   */
	public function evenement(){

		$eventInfo = $this->fb->sdk->api("/".$this->uri->segment(3)."?fields=description,cover,venue,start_time,name,location");
		$eventAttending = $this->fb->sdk->api("/".$this->uri->segment(3)."/attending");
		$SiteLoad['goingCount']=0;
		$i=0;
		$toShow = 11;
		$SiteLoad['going'] = array();
		foreach($eventAttending['data'] as $going){
			$SiteLoad['goingCount']++;
			if($i<=$toShow){
				array_push($SiteLoad['going'], array("id"=>$going['id'],
													'name' => $going['name']));
			}
			$i++;
		}
		$SiteLoad['goingCount']-=$toShow;
		$SiteLoad['eventid'] = $eventInfo['id'];
		$SiteLoad['eventName'] = $eventInfo['name'];
		$SiteLoad['eventImg'] = $eventInfo['cover']['source'];
		$SiteLoad['eventDesc'] = $eventInfo['description'];
		$SiteLoad['eventLong'] = $eventInfo['venue']['longitude'];
		$SiteLoad['eventLat'] = $eventInfo['venue']['latitude'];
		$SiteLoad['eventLoc'] = $eventInfo['location'];
		$SiteLoad['eventStr'] = $eventInfo['venue']['street'];
		$SiteLoad['eventZp'] = $eventInfo['venue']['zip'];
		$SiteLoad['eventCt'] = $eventInfo['venue']['city'];
		$SiteLoad['title'] = "Hexion";
		$this->siteload->load('event', $SiteLoad);
	}
	
	public function go(){
		$eventInfo = $this->fb->sdk->api("".$this->uri->segment(3)."/attending", "POST");
		var_dump($eventInfo);
	}
	
   
}

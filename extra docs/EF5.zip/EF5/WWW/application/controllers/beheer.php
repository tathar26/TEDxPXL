<?php if (!defined('BASEPATH')) die();
class beheer extends Main_Controller {

   public function index()
	{
		$this->load->view("beheer/beheer");
	}
	/**
   * 
   * Comment: Opvragen van leden in goedkeuring of vaste leden.
   *
   */
	
	public function leden()
	{
		$this->load->model('leden');
		$data['users']=$this->leden->get_users();
		$data['pending']=$this->leden->get_pending();
		$this->load->view("beheer/leden",$data);
	}	
	
	/**
   * 
   * Comment: Laden van evenementen beheer view
   *
   */
	
	public function evenementen()
	{
		$this->load->view("beheer/evenementen");
	}	
	
	/**
   * 
   * Comment: Laden van nieuws beheer view
   *
   */
	
	public function nieuws()
	{
		$this->load->view("beheer/nieuws");
	}	
	
	/**
   * 
   * Comment: Inladen van mogelijkheid gebruikers actief te maken
   *
   */
	
	public function make_active()
	{
		$this->load->model('leden');
		$userid=$this->uri->segment(3);
		$this->leden->make_active($userid);
	}	
	
	/**
   * 
   * Comment: Inladen manier om gebruikers inactief te maken (weigeren)
   *
   */
	
	public function make_inactive()
	{
		$this->load->model('leden');
		$userid=$this->uri->segment(3);
		$this->leden->make_inactive($userid);
	}
	
	/**
   * 
   * Comment: User Locken == Niet meer mogelijk om te posten in het forum
   *
   */
	
	public function user_lock()
	{
		$this->load->model('leden');
		$userid=$this->uri->segment(3);
		$this->leden->user_lock($userid);
	}
	/**
   * 
   * Comment: User Locken == Niet meer mogelijk om te posten in het forum
   *
   */
	
	public function user_del()
	{
		$this->load->model('leden');
		$userid=$this->uri->segment(3);
		$this->leden->user_del($userid);
	}
   
}

<?php if (!defined('BASEPATH')) die();
class Profiel extends Main_Controller {

   public function index()
	{	
		$this->load->model('profiel_info');
		$SiteLoad['title'] = "Hexion - Profiel Aanpassen";
	
		if(!$this->input->post('username')){}else{
			$this->profiel_info->editInfo('username', $this->input->post('username'), $this->session->userdata('user_id'));
			$this->profiel_info->editInfo('first_name', $this->input->post('first_name'), $this->session->userdata('user_id'));
			$this->profiel_info->editInfo('last_name', $this->input->post('last_name'), $this->session->userdata('user_id'));
			$this->profiel_info->editInfo('email', $this->input->post('email'), $this->session->userdata('user_id'));
			$this->profiel_info->editInfo('user_address', $this->input->post('user_address'), $this->session->userdata('user_id'));
			$this->profiel_info->editInfo('user_address_nr', $this->input->post('user_address_nr'), $this->session->userdata('user_id'));
			$this->profiel_info->editInfo('user_address_zip', $this->input->post('user_address_zip'), $this->session->userdata('user_id'));
			$this->profiel_info->editInfo('user_address_city', $this->input->post('user_address_city'), $this->session->userdata('user_id'));
			$this->profiel_info->editInfo('user_class', $this->input->post('user_class'), $this->session->userdata('user_id'));
			$this->profiel_info->editInfo('user_phone', $this->input->post('user_phone'), $this->session->userdata('user_id'));
		}
		
				$info = $this->profiel_info->getAllInfo('username');
		foreach($info as $item => $itemVal){
			$SiteLoad[$item] = $itemVal;
		}

		
		$this->siteload->load('profiel', $SiteLoad);
	}
	
		/** 
   * Comment: Paswoord veranderen
   */
	
	public function paswoord()
	{	
		$change = $this->ion_auth->change_password($identity, $this->input->post('old'), $this->input->post('new'));
	}
	
		/** 
   * Comment: nieuwe gebruiker creeëren
   */
	
	public function create()
	{
		$username = strtolower($this->input->post('username'));
		$email    = strtolower($this->input->post('email'));
		$password = $this->input->post('password');

		$additional_data = array(
			'first_name' => $this->input->post('first_name'),
			'last_name'  => $this->input->post('last_name'),
		);
		if ($this->ion_auth->register($username, $password, $email, $additional_data))
		{
			$this->ion_auth->login($email, $password, '0');
			redirect("home", 'refresh');
		}

	}
   
}

<?php if (!defined('BASEPATH')) die();
class overons extends Main_Controller {


	/** 
   * Comment: Formulier om te registreren
   */
   public function index()
	{
					$data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

			$data['first_name'] = array(
				'name'  => 'first_name',
				'id'    => 'first_name',
				'type'  => 'text',
			 'placeholder' => 'voornaam',
			 'class'=>'form-control',
				'value' => $this->form_validation->set_value('first_name'),
			);
			$data['username'] = array(
				'name'  => 'username',
				'id'    => 'username',
				'type'  => 'text',
			 'placeholder' => 'Gebruikersnaam',
			 'class'=>'form-control',
				'value' => $this->form_validation->set_value('username'),
			);
			$data['last_name'] = array(
				'name'  => 'last_name',
				'id'    => 'last_name',
				'type'  => 'text',
				'placeholder' => 'achternaam',
			 'class'=>'form-control',
				'value' => $this->form_validation->set_value('last_name'),
			);
			$data['email'] = array(
				'name'  => 'email',
				'id'    => 'email',
				'type'  => 'text',
				'placeholder' => 'e-mail',
			 'class'=>'form-control',
				'value' => $this->form_validation->set_value('email'),
			);
			$data['password'] = array(
				'name'  => 'password',
				'id'    => 'passwordd',
				'type'  => 'password',
				'placeholder' => 'paswoord',
			 'class'=>'form-control',
				'value' => $this->form_validation->set_value('password'),
			);
			$data['password_confirm'] = array(
				'name'  => 'password_confirm',
				'id'    => 'password_confirmm',
				'type'  => 'password',
				'placeholder' => 'paswoord bevestigen',
			 'class'=>'form-control',
				'value' => $this->form_validation->set_value('password_confirm'),
			);
			
			
			
		
			
			


		$data['title'] = "Hexion";
		$this->siteload->load('overons', $data);
	}
   
}

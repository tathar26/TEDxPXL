<?php if (!defined('BASEPATH')) die();
class fotos extends Main_Controller {

   public function index()
	{
		$fql = urlencode('{"query1":"SELECT object_id, name, cover_pid FROM album WHERE owner = '.$this->config->item('pageid').'","query2":"SELECT src_big FROM photo WHERE pid IN (SELECT cover_pid FROM #query1)"}');
		$fb_albums = $this->fb->sdk->api("/fql?q={$fql}");
		$i=0;
		$SiteLoad['albums']=array();
		foreach($fb_albums['data'][0]['fql_result_set'] as $row){
			if(isset($fb_albums['data'][1]['fql_result_set'][$i]['src_big'])){
			$SiteLoad['albums'][$i]['name'] = $row['name'];
			$SiteLoad['albums'][$i]['img'] = $fb_albums['data'][1]['fql_result_set'][$i]['src_big'];
			$SiteLoad['albums'][$i]['id'] = $row['object_id'];
			}
			$i++;
		}
		
		$SiteLoad['title'] = "Hexion";
		$this->siteload->load('fotos', $SiteLoad);
		
	}
	
	   public function album()
	{
		$SiteLoad['photos'] = $this->fb->sdk->api("/".$this->uri->segment(3)."/photos?fields=source");
		$SiteLoad['title'] = "Hexion";
		$this->siteload->load('album', $SiteLoad);
	}

   
}

<?php if (!defined('BASEPATH')) die();
class home extends Main_Controller {
	
		/** 
   * Comment: niet gebruikt (kan later als extra dienen)
   */

   public function index()
	{
		$SiteLoad['title'] = "Hexion";
		$this->siteload->load('home', $SiteLoad);
		
	}
   
}

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forum_model extends CI_Model
{

/** 
   * Comment: Constructor oproepen
   */
    function __construct()
    {
        parent::__construct();
    }
	/** 
   * Comment: Items in het forum verkrijgen
   */
    function getItems()
    {
         	$this->db->select('forum_item.id, forum_item.title, forum_reaction.content, users.first_name, forum_reaction.time');
			$this->db->from('forum_item');
			$this->db->join('forum_reaction', 'forum_item.id = forum_reaction.item_id');
			$this->db->join('users', 'users.id = forum_reaction.user');
			$this->db->group_by("forum_item.id");
			$this->db->order_by("forum_reaction.time", "desc"); 
			$query = $this->db->get();
        return $query->result();
    }
	
}

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forum_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }
    
	/** 
   * Comment: Array teruggeven met alle forumtopics
   */
    function getItems()
    {
         	$this->db->select('forum_item.id, forum_item.title, forum_reaction.content, users.first_name, forum_reaction.time');
			$this->db->from('forum_item');
			$this->db->join('forum_reaction', 'forum_item.id = forum_reaction.item_id');
			$this->db->join('users', 'users.id = forum_reaction.user');
			$this->db->group_by("forum_item.id");
			$this->db->order_by("forum_reaction.time", "desc"); 
			$query = $this->db->get();
        return $query->result();
    }
	
/** 
   * Comment: Alle reacties van een topic teruggeven
   */

	 function getContent(){

			$this->db->select('forum_reaction.content, forum_reaction.id, users.first_name, users.last_name, users.id as userID, users.fb, forum_reaction.time');
			$this->db->from('forum_item');
			$this->db->join('forum_reaction', 'forum_item.id = forum_reaction.item_id');
			$this->db->join('users', 'users.id = forum_reaction.user');
			$this->db->where("forum_item.id", $this->uri->segment(3));
			$this->db->order_by("forum_reaction.time", "asc"); 
			$query = $this->db->get();
			$data['return']=array();
			foreach($query->result() as $row){
				if($row->fb == 0){
					$row->userimg = "http://graph.facebook.com/1/picture";
				}else{
					$row->userimg = "http://graph.facebook.com/".$row->fb."/picture";
				}
				$row->time = date("d/m/Y - H:i", $row->time);
				array_push($data['return'], $row);
			}
			return $data['return'];
	}
	/** 
   * Comment: nieuw topic
   */
	public function newTopic($title, $content){
		$data = array(
			   'title' => $title,
			   'creator' => $this->session->userdata('user_id'),
			   'time' => time()
			);

		$this->db->insert('forum_item', $data); 
		
		$newId = $this->db->insert_id();
		
		$data = array(
				'item_id' => $newId,
			   'content' => $content,
			   'user' => $this->session->userdata('user_id'),
			   'time' => time()
			);

		$this->db->insert('forum_reaction', $data); 
		
		return $newId;
	}
	/** 
   * Comment: nieuwe reactie
   */
	public function newComment($item, $content){
		$data = array(
			   'content' => $content,
			   'item_id' => $item,
			   'user' => $this->session->userdata('user_id'),
			   'time' => time()
			);

		$this->db->insert('forum_reaction', $data); 
	}
	/** 
   * Comment: reactie wijzigen
   */
	public function editComment($item, $content){
		$this->db->where('id', $item);
		$data = array('content' => $content);

		$this->db->update('forum_reaction', $data); 
	}
	
	/** 
   * Comment: reactie verwijderen
   */
	
	public function delComment($item){
		$this->db->delete('forum_reaction', array('id' => $item)); 
	}
	
	/** 
   * Comment: forum doorzoeken
   */
	public function searchItems($query){
			$this->db->select('forum_item.id, forum_item.title, forum_reaction.content, users.first_name, forum_reaction.time');
			$this->db->from('forum_item');
			$this->db->join('forum_reaction', 'forum_item.id = forum_reaction.item_id');
			$this->db->join('users', 'users.id = forum_reaction.user');
			$this->db->like('forum_item.title',$query);
			$this->db->group_by("forum_item.id");
			$this->db->order_by("forum_reaction.time", "desc"); 
			$query = $this->db->get();
			return $query->result();
	}
	/** 
   * Comment: creator van een reactie verkrijgen voor permissies
   */
	function getCreator($item){

			$this->db->select('forum_reaction.user');
			$this->db->from('forum_reaction');
			$this->db->where("forum_item.id", $item);
			$query = $this->db->get();
			$info = $query->result();
        	return $info[0];
	}

}

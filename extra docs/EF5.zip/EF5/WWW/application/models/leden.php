<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Leden extends CI_Model
{

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    /** 
   * Comment: alle leden verkrijgen
   */
    function get_users()
    {
         $this->db->select('users.id,users.username, users.email, users.first_name, users.last_name, users.fb, users_details.*');
         $this->db->from('users');
         $this->db->join('users_details', 'users.id = users_details.user_id', "left");
		 $this->db->where('users.active ="1"');
         $i=0;
         
         $query = $this->db->get();
        foreach ($query->result() as $row)
        {
          $data[$i]=$row;
          $i++;
        }
        return $data;
    }
	/** 
   * Comment: alle leden verkrijgen die nog wachten op goedkeuring
   */
	function get_pending()
    {
         $this->db->select('users.id,users.username, users.email, users.first_name, users.last_name, users.fb, users_details.*');
         $this->db->from('users');
         $this->db->join('users_details', 'users.id = users_details.user_id', "left");
		 $this->db->where('users.active ="0"');
         $i=0;
         
         $query = $this->db->get();
		 if($query->num_rows()>0){
        foreach ($query->result() as $row)
        {
          $data[$i]=$row;
          $i++;
        }
        return $data;
    } else return null;
	} 
	
	/** 
   * Comment: een user actief maken (goedkeuren)
   */
	function make_active($userid)
    {
		$data = array(
               'active' => "1"
            );

			$this->db->where('id', $userid);
			$this->db->update('users', $data); 
	}
	
	/** 
   * Comment: een user inactief maken
   */
	function make_inactive($userid)
     {
		$data = array(
               'active' => "2"
            );

			$this->db->where('id', $userid);
			$this->db->update('users', $data); 
	}


}

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Zoek_model extends CI_Model {

    function __construct()
    {
        parent::__construct();
    }
	/** 
   * Comment: website doorzoeken naar items
   */
	function searchItems($query)
    {
		$this->db->select('forum_item.title, forum_item.id');
       $this->db->from('forum_item');
		$this->db->like('title', $query);
		$query_ex = $this->db->get();
		$result['forum_items'] = $query_ex->result_array();
		
		$this->db->select('forum_reaction.content, forum_reaction.id');
       $this->db->from('forum_reaction');
		$this->db->like('content', $query);
		$query_ex = $this->db->get();
		$result['forum_content'] = $query_ex->result_array();
		
		$fb_query = "SELECT eid, name, start_time FROM event WHERE creator = ".$this->config->item('pageid')." AND strpos(lower(name),lower('".$query."')) >=0 ORDER BY start_time desc";
		$fb_result = $this->fb->sdk->api(array('method' => 'fql.query', 'query' =>$fb_query));
		$i=0;
		$result['fb']=array();
		foreach($fb_result as $row){
			$result['fb'][$i]['date'] = date("d/m/Y", strtotime($row['start_time']));
			$result['fb'][$i]['name'] = $row['name'];
			$result['fb'][$i]['eid'] = $row['eid'];
			$i++;
		}

        return $result;


    }


}
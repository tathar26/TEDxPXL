<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Profiel_info extends CI_Model {

    function __construct()
    {
        parent::__construct();
    }
	
	function getInfo($soort)
    {
		$this->db->select($soort);
       $this->db->from('users');
       $this->db->join('users_details', 'users.id = users_details.user_id', "left");
		$this->db->where('user_id', $this->session->userdata('user_id'));
		$query = $this->db->get();
		$info = $query->result();
		$info = $info[0]->{$soort};
        return $info;
    }
	
	function getAllInfo()
    {
		$this->db->select('*');
       $this->db->from('users');
       $this->db->join('users_details', 'users.id = users_details.user_id', "left");
		$this->db->where('users.id', $this->session->userdata('user_id'));
		$query = $this->db->get();
		$info = $query->result();
		$info = $info[0];
        return $info;
    }
	
	function editInfo($item, $val, $id){
		
		$this->db->where('id', $id);
		$data = array($item => $val);
		$this->db->update('users JOIN users_details ON users.id = users_details.user_id', $data); 



	}


}
<?php

$lang['ut_test_name'] = 'Test Naam';
$lang['ut_test_datatype'] = 'Test Datatype ';
$lang['ut_res_datatype'] = 'Verwachte Datatype';
$lang['ut_result'] = 'Resultaat';
$lang['ut_undefined'] = 'Ongedefinieerde Test Naam';
$lang['ut_file'] = 'Bestandsnaam';
$lang['ut_line'] = 'Regelnummer';
$lang['ut_passed'] = 'Succesvol';
$lang['ut_failed'] = 'Mislukt';
$lang['ut_boolean'] = 'Boolean';
$lang['ut_integer'] = 'Integer';
$lang['ut_float'] = 'Float';
$lang['ut_double'] = 'Double';
$lang['ut_string'] = 'String';
$lang['ut_array'] = 'Array';
$lang['ut_object'] = 'Object';
$lang['ut_resource'] = 'Resource';
$lang['ut_null'] = '';
$lang[''] = '';
?>
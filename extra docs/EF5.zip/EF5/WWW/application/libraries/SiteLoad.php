<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class SiteLoad {
		
    public function load($view, $SiteLoad)
    {
	  $ci =& get_instance();
	  
	  //facebook login laden
	  		$user = $ci->fb->sdk->getUser();

        if ($user) {
            try {
                $login['user_profile'] = $ci->fb->sdk->api('/me');
            } catch (FacebookApiException $e) {
                $user = null;
            }
        }
        if ($user) {
            $login['logout_url'] = $ci->fb->sdk->getLogoutUrl();
        } else {
			 $params = array(
  				'scope' => 'email,rsvp_event,friends_events,user_events',
  				'redirect_uri' => base_url('auth/fb_login')
			 );
            $login['login_url'] = $ci->fb->sdk->getLoginUrl($params);
        }

	  
	  //Login checken 
	  if($ci->ion_auth->logged_in()){
		  if($ci->ion_auth->is_admin()){
	  		$loggedin['admin'] = 1;
		  }else{
			$loggedin['admin'] = 0;
		  }
		  $loggedin['active'] = $ci->ion_auth->user()->row()->active;
		  
		  $menu['login'] = $ci->load->view('include/loggedin', $loggedin, TRUE);
	  }else{
		  $SiteLoad['active'] = 0;
		  $menu['login'] = $ci->load->view('include/login', $login, TRUE);
	  }

	  //Menu items 
		$menuItems = array(array("item" => "Home", "controller" => "home"),
					   	array("item" => "Evenementen","controller" => "evenementen"),
					   	array("item" => "Foto's","controller" => "fotos"),
						array("item" => "Forum","controller" => "forum"),
						array("item" => "Over ons","controller" => "overons"),
						array("item" => "Contact","controller" => "contact")
					);
					
		 $i = 0;
	  	 foreach($menuItems as $item){
			 if($item['controller']==$ci->router->class){
				 $item['active']='active';
			 }else{
				 $item['active']='';
			 }
			 $menuItems[$i] = $item;
			 $i++;
		 }
	  
	  $ci->session->set_userdata('lastPage', $ci->router->class);
	  
	  $menu['items'] = $menuItems;
	  $footer['items'] = $menuItems;
	  //Vieuws Laden
	  if(!isset($SiteLoad['title'])){
		  $SiteLoad['title']="Hexion";
	  }
	  $ci->load->view('include/header', $SiteLoad);
	  $ci->load->view('include/menu', $menu);
	  if($ci->ion_auth->logged_in() && $ci->ion_auth->user()->row()->active ==0){
      		$ci->load->view('include/notActive');
	  }
      $ci->load->view($view);
      $ci->load->view('include/footer', $footer);

    }
}


<?php

class Fb {
   
   private $appid = '';
   private $secret = '';

   public function __construct()
   {
      $ci =& get_instance();
      $this->appid = $ci->config->item('appId');
      $this->secret = $ci->config->item('secret');

      //load the library
      $this->load();
   }

   private function load()
   {
      include_once 'facebook.php';
      $credentials = array(
         'appId' => $this->appid,
         'secret' => $this->secret
      );

      $this->sdk = new Facebook($credentials);
   }      

}

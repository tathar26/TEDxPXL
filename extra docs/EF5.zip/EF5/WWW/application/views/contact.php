<div class="row">
<div class="col-md-2"></div>
<div class="col-md-5">
<div id="contact_form" class="row">
  <div class="col-12 col-sm-12 col-lg-12">
    <h2>Contacteer ons!</h2>
    
    <form role="form" id="feedbackForm">
      <div class="form-group">
        <input type="text" class="form-control" id="name" name="name" placeholder="Naam">
        <span class="help-block" style="display: none;">Gelieve uw naam op te geven.</span>
      </div>
      <div class="form-group">
        <input type="email" class="form-control" id="email" name="email" placeholder="E-mail adres">
        <span class="help-block" style="display: none;">Gelieve uw email-adres op te geven.</span>
      </div>
      <div class="form-group">
        <textarea rows="10" cols="100" class="form-control" id="message" name="message" placeholder="Uw boodschap"></textarea>
        <span class="help-block" style="display: none;">Gelieve een boodschap in te geven.</span>
      </div>
      <img id="captcha" src="/assets/library/vender/securimage/securimage_show.php" alt="CAPTCHA Image" />
      <a href="#" onclick="document.getElementById('captcha').src = '/assets/library/vender/securimage/securimage_show.php?' + Math.random(); return false" class="btn btn-info btn-sm">Geef een nieuwe code weer</a><br/>
      <div class="form-group" style="margin-top: 10px;">
        <input type="text" class="form-control" name="captcha_code" id="captcha_code" placeholder="Gelieve uw beveiligheidscode hier te typen" />
        <span class="help-block" style="display: none;">Gelieve de correcte code in te geven.</span>
      </div>
       
      <span class="help-block" style="display: none;">Gelieve de correcte code in te geven.</span>
      <button type="submit" id="feedbackSubmit" class="btn btn-primary btn-lg" style="display: block; margin-top: 10px;">Verstuur</button>
    </form>
  </div>
</div>
</div>
<div class="col-md-5"></div>
</div>

<script>
$(document).ready(function() {
  $("#feedbackSubmit").click(function() {
    //clear any errors
    contactForm.clearErrors();
 
    //do a little client-side validation -- check that each field has a value and e-mail field is in proper format
    var hasErrors = false;
    $('#feedbackForm input,textarea').each(function() {
      if (!$(this).val()) {
        hasErrors = true;
        contactForm.addError($(this));
      }
    });
    var $email = $('#email');
    if (!contactForm.isValidEmail($email.val())) {
      hasErrors = true;
      contactForm.addError($email);
    }
 
    //if there are any errors return without sending e-mail
    if (hasErrors) {
      return false;
    }
 
    //send the feedback e-mail
    $.ajax({
      type: "POST",
      url: '<?php echo base_url('contact/sendemail')?>',
      data: $("#feedbackForm").serialize(),
      success: function(data)
      {
        contactForm.addAjaxMessage(data.message, false);
        //get new Captcha on success
        $('#captcha').attr('src', '<?php echo base_url()?>assets/library/vender/securimage/securimage_show.php?' + Math.random());
      },
      error: function(response)
      {
        
      }
   });
    return false;
  }); 
});
 
//namespace as not to pollute global namespace
var contactForm = {
  isValidEmail: function (email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
  },
  clearErrors: function () {
    $('#emailAlert').remove();
    $('#feedbackForm .help-block').hide();
    $('#feedbackForm .form-group').removeClass('has-error');
  },
  addError: function ($input) {
    $input.siblings('.help-block').show();
    $input.parent('.form-group').addClass('has-error');
  },
  addAjaxMessage: function(msg, isError) {
    $("#feedbackSubmit").after('<div id="emailAlert" class="alert alert-' + (isError ? 'danger' : 'success') + '" style="margin-top: 5px;">' + "Bericht verzonden" +'</div>');
  }
}; </script>
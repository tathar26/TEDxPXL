<div class="row">
<?php foreach($albums as $album){ ?>
  <div class="col-sm-6 col-md-4">
    <div class="thumbnail">
      <a href="<?php echo base_url('fotos/album/'.$album['id']) ?>"><img src="<?=$album['img']?>" style="width:100%" alt="album"></a>
      <div class="caption" style="text-align:center">
        <h4><?=$album['name']?></h4>
      </div>
    </div>
  </div>
<?php } ?>
</div>

<div class="row">
<?php foreach($photos['data'] as $album){ ?>
  <div class="col-sm-6 col-md-4">
    <div class="thumbnail">
      <img src="<?=$album['source']?>" style="width:100%" alt="...">
    </div>
  </div>
<?php } ?>
</div>

<?php if($pending != null){ ?>
<h3>Openstaande verzoeken</h3>

<table id="demo" class="table table-striped table-hover table-condensed">
  <thead>
    <tr>
      <th>User</th>
      <th>Firstname</th>
      <th>Lastname</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody">
    <?php 
 foreach($pending as $user){
	 ?>
    <tr id="user_<?=$user->id?>">
      <td><?=$user->username?></td>
      <td><?=$user->first_name?></td>
      <td><?=$user->last_name?></td>
      <td><button type="button" class="lidgoedkeuren btn btn-success btn-xs" id="<?=$user->id?>" data-toggle="tooltip" data-placement="left" title="Tooltip on left"> <span class="glyphicon glyphicon-ok"></span> </button>
        <button type="button" class="btn btn-danger btn-xs"> <span class="glyphicon glyphicon-remove"></span> </button></td>
        
    </tr>
    <?php
	 }
 ?>
  </tbody>
</table>
<p></p>
<?php }?>
<h3>Ledenlijst</h3>
<table class="table table-striped">
  <thead>
    <tr>
      <th>User</th>
      <th>Firstname</th>
      <th>Lastname</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php 
 foreach($users as $user){
	 ?>
    <tr>
      <td><?=$user->username?></td>
      <td><?=$user->first_name?></td>
      <td><?=$user->last_name?></td>
      <td><button type="button" class="btn btn-default btn-xs"> <span class="glyphicon glyphicon-lock"></span> </button>
        <button type="button" class="btn btn-default btn-xs" data-bb="confirm"> <span class="glyphicon glyphicon-trash"></span> </button>
        <div class="btn btn-default btn-xs"><a data-toggle="modal" data-target="#editUser"> <span class="glyphicon glyphicon-pencil"></span> </div></td>
        
    </tr>
    <?php
	 }
 ?>
  </tbody>
</table>

<script>
$('.lidgoedkeuren').on('click',function(){
	var userid = $(this).attr('id');
	$.post("/beheer/make_active/"+userid, function(data){
		$('#user_'+userid).hide();
	});	
	});
</script>

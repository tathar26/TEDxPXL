<div class="row">
<div class="col-md-2"></div>
<div class="col-md-10">
<form class="form-horizontal" method="post">
<div class="row">
<fieldset>

<!-- Form Name -->
<legend>Accountinformatie</legend>
</div>
<div class="col-md-4">
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="Gebruiksnaam">Gebruiksnaam</label>
  <div class="controls">
    <input id="Gebruiksnaam" name="username" type="text" placeholder="Gebruikersnaam" class="form-control" value="<?php echo $username; ?>">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="first_name">Voornaam</label>
  <div class="controls">
    <input id="Voornaam" name="first_name" type="text" placeholder="Voornaam" class="form-control" value="<?php echo $first_name; ?>">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="last_name">Naam</label>
  <div class="controls">
    <input id="Naam" name="last_name" type="text" placeholder="Naam" class="form-control" value="<?php echo $last_name; ?>">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="email">E-mail</label>
  <div class="controls">
    <input id="E-mail" name="email" type="text" placeholder="E-mail" class="form-control" value="<?php echo $email; ?>">
    
  </div>
</div>
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="user_phone">Telefoon</label>
  <div class="controls">
    <input id="Klas" name="user_phone" type="text" placeholder="Telefoon" class="form-control" value="<?php echo $user_phone; ?>">
    
  </div>
</div>



</div>
<div class="col-md-4">
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="user_address">Adres</label>
  <div class="controls">
    <input id="Adress" name="user_address" type="text" placeholder="Adres" class="form-control"value="<?php echo $user_address; ?>">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="user_address_nr">Huisnummer</label>
  <div class="controls">
    <input id="Huisnummer" name="user_address_nr" type="text" placeholder="Huisnummer" class="form-control" value="<?php echo $user_address_nr; ?>">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="user_address_zip">Postcode</label>
  <div class="controls">
    <input id="Postcode" name="user_address_zip" type="text" placeholder="Postcode" class="form-control" value="<?php echo $user_address_zip; ?>">
    
  </div>
</div>
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="user_address_city">Gemeente</label>
  <div class="controls">
    <input id="Gemeente" name="user_address_city" type="text" placeholder="Gemeente" class="form-control" value="<?php echo $user_address_city; ?>">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="user_class">Klas</label>
  <div class="controls">
    <input id="Klas" name="user_class" type="text" placeholder="Klas" class="form-control" value="<?php echo $user_class; ?>">
    
  </div>
</div>

<!-- Button -->
<br/>
<div class="control-group">
  <div class="controls">
    <button id="Opslaan" name="Opslaan" class="btn btn-primary">Sla de wijzigingen op</button>
  </div>
</div>
</div>
<div class="col-md-4">
</div>

</fieldset>
</form>

</div>
</div>
<br/><br/>
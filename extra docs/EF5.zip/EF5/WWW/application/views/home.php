<div class="row">
  <div class="col-xs-12 col-md-8">
    <div class="row">
      <div class="jumbotron">
  <h1>Word jij lid?!</h1>
  <p>Word lid en geniet van vele voordelen!</p>
  <p><a class="btn btn-primary btn-lg" href="<?php echo base_url("overons");?>#LidWorden"role="button">Lid Worden</a></p>
</div>
    </div>
  </div>
  <div class="col-xs-12 col-md-4">
    <a class="twitter-timeline" href="https://twitter.com/Hexion1" data-widget-id="433527694387470336">Tweets by @Hexion1</a> 
    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script> 
  </div>
</div>
<br />

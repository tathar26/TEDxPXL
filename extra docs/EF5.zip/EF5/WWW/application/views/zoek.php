<?php //var_dump($return); ?>
<?php if(count($return['fb']) != 0){ ?>
<legend>Evenementen</legend>
<div class="list-group">
	<?php foreach($return['fb'] as $row){ ?>
      <a href="<?php echo base_url("evenementen/evenement/".$row['eid']); ?>" class="list-group-item">
        <h4 class="list-group-item-heading"><?=$row['name']?></h4>
        <p class="list-group-item-text"><?=$row['date']?></p>
      </a>
  <?php } ?>
</div>

<?php } ?>
<?php if(count($return['forum_items']) > 0){ ?>
<legend>Forum Topics</legend>
<div class="list-group">
	<?php foreach($return['forum_items'] as $row){ ?>
      <a href="<?php echo base_url("forum/".$row['id']); ?>" class="list-group-item">
        <h4 class="list-group-item-heading"><?=$row['title']?></h4>
      </a>
  <?php } ?>
</div>

<?php } ?>


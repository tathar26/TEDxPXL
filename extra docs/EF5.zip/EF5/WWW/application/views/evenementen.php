<div class="container">
	

	<div class="page-header">

		<div class="pull-right form-inline">
			<div class="btn-group">
				<button class="btn btn-primary" data-calendar-nav="prev">&lt;&lt; Vorige</button>
				<button class="btn" data-calendar-nav="today">Vandaag</button>
				<button class="btn btn-primary" data-calendar-nav="next">Volgende >></button>
			</div>
			<div class="btn-group">
				<button class="btn btn-warning" data-calendar-view="year">Jaar</button>
				<button class="btn btn-warning active" data-calendar-view="month">Maand</button>
				<button class="btn btn-warning" data-calendar-view="week">Week</button>
			</div>
		</div>

		<h3></h3>
	</div>

	<div class="row">
		<div class="span9">
			<div id="calendar"></div>
		</div>
	</div>
    <br />

	<div class="modal hide fade" id="events-modal">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			<h3>Event</h3>
		</div>
		<div class="modal-body" style="height: 400px">
		</div>
		<div class="modal-footer">
			<a href="#" data-dismiss="modal" class="btn">Close</a>
		</div>
	</div>

	<script type="text/javascript" src="/assets/components/underscore/underscore-min.js"></script>
	<script type="text/javascript" src="/assets/components/jstimezonedetect/jstz.min.js"></script>
	<script type="text/javascript" src="/assets/js/language/nl-NL.js"></script>
	<script type="text/javascript" src="/assets/js/language/fr-FR.js"></script>
	<script type="text/javascript" src="/assets/js/language/de-DE.js"></script>
	<script type="text/javascript" src="/assets/js/language/el-GR.js"></script>
	<script type="text/javascript" src="/assets/js/language/it-IT.js"></script>
	<script type="text/javascript" src="/assets/js/language/pl-PL.js"></script>
	<script type="text/javascript" src="/assets/js/language/pt-BR.js"></script>
	<script type="text/javascript" src="/assets/js/language/es-MX.js"></script>
	<script type="text/javascript" src="/assets/js/language/es-ES.js"></script>
	<script type="text/javascript" src="/assets/js/language/ru-RU.js"></script>
	<script type="text/javascript" src="/assets/js/language/sv-SE.js"></script>
    <script type="text/javascript" src="/assets/js/language/zh-CN.js"></script>
	<script type="text/javascript" src="/assets/js/calendar.js"></script>
	<script type="text/javascript">
    (function($) {

	"use strict";
	
	

	var options = {
		events_source: '<?php echo base_url('/evenementen/events/')?>',
		view: 'month',
		tmpl_path: '<?php echo base_url('/assets/tmpls/')?>',
		tmpl_cache: false,
		day: 'now',
		onAfterEventsLoad: function(events) {
			if(!events) {
				return;
			}
			var list = $('#eventlist');
			list.html('');

			$.each(events, function(key, val) {
				$(document.createElement('li'))
					.html('<a href="' + val.url + '">' + val.title + '</a>')
					.appendTo(list);
			});
		},
		onAfterViewLoad: function(view) {
			$('.page-header h3').text(this.getTitle());
			$('.btn-group button').removeClass('active');
			$('button[data-calendar-view="' + view + '"]').addClass('active');
		},
		classes: {
			months: {
				general: 'label'
			}
		}
	};

	var calendar = $('#calendar').calendar(options);

	$('.btn-group button[data-calendar-nav]').each(function() {
		var $this = $(this);
		$this.on('click',function() {
			calendar.navigate($this.data('calendar-nav'));
		});
	});

	$('.btn-group button[data-calendar-view]').each(function() {
		var $this = $(this);
		$this.on('click',function() {
			calendar.view($this.data('calendar-view'));
		});
	});

	$('#first_day').change(function(){
		var value = $(this).val();
		value = value.length ? parseInt(value) : null;
		calendar.setOptions({first_day: value});
		calendar.view();
	});

	$('#events-in-modal').change(function(){
		var val = $(this).is(':checked') ? $(this).val() : null;
		calendar.setOptions({modal: val});
	});
	$('#events-modal .modal-header, #events-modal .modal-footer').on('click',function(e){
		//e.preventDefault();
		//e.stopPropagation();
	});
}(jQuery));
    </script>

</div>
<div class="alert alert-warning"><b>Nog niet actief:</b> Je account is nog niet actief. Hierdoor kan je nog niets extra doen.</div>

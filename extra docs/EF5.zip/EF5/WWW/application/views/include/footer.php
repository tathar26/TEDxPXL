</div>

<div id="footer">
<br />
<div class="container">
		<div class="col-md-3">
				<h4 style="color:#FFF">Navigatie </h4>
        		<?php foreach($items as $item){ ?>
				<a href="<?=$item['controller']?>" style="color:#FFF"><?=$item['item']?></a><br />
               <?php } ?>
		</div>
		<div class="col-md-5">
				<h4 style="color:#FFF">Social Media </h4><br />
				<div class="fb-facepile" data-href="https://www.facebook.com/pages/Studentenvereniging-Hexion/1428715620681598" data-max-rows="1" data-colorscheme="light" data-size="medium" data-show-count="true"></div>
                <div><br />
                <a href="https://www.facebook.com/pages/Studentenvereniging-Hexion/1428715620681598?fref=ts"><img src="/assets/img/icons/facebook-icon.png" alt="Facebook"></a>
                <a href="https://twitter.com/Hexion1"><img src="/assets/img/icons/twitter-icon.png" alt="Facebook"></a>
                <a href="mailto:Studentenvereniging.hexion@gmail.com"><img src="/assets/img/icons/google-icon.png" alt="Facebook"></a>
                <a href="http://www.youtube.com/channel/UCQQJ9lK425B_Dje_wta2RdA"><img src="/assets/img/icons/youtube-icon.png" alt="Facebook"></a>
                </div>
		</div>
		<div class="col-md-4">
				<h4 style="color:#FFF">Meer info over ons </h4><br />
                <address>
  <strong>Studentenvereniging Hexion</strong><br>
  Elfde-Liniestraat 11, 3500 Hasselt<br>
  België, Limburg<br>
  <abbr title="Phone">Tel:</abbr> (+32) 11 77 55 55
</address>

<address>
  <strong>Hexion Contact</strong><br>
  <a href="mailto:#" style="color:#FFF">email@weetkveel.be</a>
</address>

		</div>
</div>
</div>
<div id="fb-root"></div>
<script>
(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=241859905992660";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script> 
<script src="//cdnjs.cloudflare.com/ajax/libs/lodash.js/1.3.1/lodash.min.js"></script> 
<script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script> 
<script src="<?php echo base_url('assets/js/custom.js') ?>"></script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-47802612-1', 'artmex.be');
  ga('send', 'pageview');

</script>
</body>
</html>


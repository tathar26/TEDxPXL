
<div class="row" style="text-align:right; padding-bottom:20px;"> <a class="btn btn-primary" data-toggle="modal" data-target="#myModal">Aanmelden</a> </div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="width:300px">
    <div class="modal-content">
      <?php 
		$form_at = array('class' => 'form-horizontal', 'id'=>'loginForm');
		echo form_open("auth/login", $form_at);?>
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Hexion Login</h4>
      </div>
      <div class="modal-body"> 
      		<div id="loginError"></div>
      		<div id="fbLogin">
      			<a href="<?php echo $login_url?>" style="width:100%" class="btn btn-facebook">
            	<span class="fa fa-facebook"></span> | Meld aan met Facebook
           	</a><br />
           </div>
        <br />
        <div class="form-group">
          <div class="col-sm-12">
            <input type="email" class="form-control" id="identity" name="identity" placeholder="Email">
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-12">
            <input type="password" class="form-control" id="password" name="password" placeholder="Password">
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-offset-2 col-sm-10">
            <div class="checkbox">
              <label>
                <input type="checkbox" name="remember" id="remember">Remember me </label>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
      <a href="<?php echo base_url("overons");?>#LidWorden" style="margin-right:10px;">Nog geen account?</a>
 <button type="submit" name="submit" id="loginButton" class="btn btn-primary">Aanmelden</button>     </div>
      <?php echo form_close();?> </div>
  </div>
</div>
<script type="application/javascript">
$(document).ready(function() {
     $("#loginForm").submit(function(event) {
            event.preventDefault(); 
            $.post( "/auth/js_login", $(this).serialize(), function(data){
                if(data.result == 1){
					location.reload();
				  }else{
					$("#loginError").html("<div class='alert alert-danger'>"+data.error+"</div>");
				  }
            }, "json");
        });
});
</script> 

<div class="row" style="text-align:right; padding-bottom:20px;"><a href="<?php echo base_url('profiel')?>">Bewerk profiel</a> <?php if($admin==1){ ?> / <a data-toggle="modal" data-target="#beheer" id="beheerOpen">beheer</a> <?php } ?><a class="btn btn-primary" href="/auth/logout" style="margin-left:10px;">Afmelden</a> </div>
<?php if($admin==1){ ?>
<div class="modal fade bs-modal-lg" tabindex="-1" role="dialog" id="beheer" aria-hidden="true">
		<div class="modal-dialog modal-lg">
				<div class="modal-content">
						<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
								<h4 class="modal-title" id="myModalLabel">Beheer</h4>
						</div>
						<div class="modal-body"> 
								<!-- Nav tabs -->
								<ul class="nav nav-tabs">
										<li class="active"><a href="#leden" data-toggle="tab">Ledenbeheer</a></li>
										<li><a href="#evenementen" data-toggle="tab">Evenementen</a></li>
										<li><a href="#nieuws" data-toggle="tab">Nieuwsoverzicht</a></li>
								</ul>
								
								<!-- Tab panes -->
								<div class="tab-content" style="height:300px; overflow:scroll">
										<div class="tab-pane active" id="leden"></div>
										<div class="tab-pane" id="evenementen"></div>
										<div class="tab-pane" id="nieuws"></div>
								</div>
						</div>
						<div class="modal-footer">
						</div>
				</div>
		</div>
</div>

<div class="modal fade bs-modal-lg" tabindex="-1" role="dialog" id="editUser" aria-hidden="true">
		<div class="modal-dialog modal-lg">
				<div class="modal-content">
						<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
								<h4 class="modal-title" id="myModalLabel">Administratiebeheer</h4>
						</div>
						<div class="modal-body"> 
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="Gebruiksnaam">Gebruiksnaam</label>
  <div class="controls">
    <input id="Gebruiksnaam" name="Gebruiksnaam" type="text" placeholder="Gebruikersnaam" class="form-control">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="Voornaam">Voornaam</label>
  <div class="controls">
    <input id="Voornaam" name="Voornaam" type="text" placeholder="Voornaam" class="form-control">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="Naam">Naam</label>
  <div class="controls">
    <input id="Naam" name="Naam" type="text" placeholder="Naam" class="form-control">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="E-mail">E-mail</label>
  <div class="controls">
    <input id="E-mail" name="E-mail" type="text" placeholder="E-mail" class="form-control">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="Adress">Adres</label>
  <div class="controls">
    <input id="Adress" name="Adress" type="text" placeholder="Adres" class="form-control">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="Huisnummer">Huisnummer</label>
  <div class="controls">
    <input id="Huisnummer" name="Huisnummer" type="text" placeholder="Huisnummer" class="form-control">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="Postcode">Postcode</label>
  <div class="controls">
    <input id="Postcode" name="Postcode" type="text" placeholder="Postcode" class="form-control">
    
  </div>
</div>
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="Gemeente">Gemeente</label>
  <div class="controls">
    <input id="Gemeente" name="Gemeente" type="text" placeholder="Gemeente" class="form-control">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="Klas">Klas</label>
  <div class="controls">
    <input id="Klas" name="Klas" type="text" placeholder="Klas" class="form-control">
    
  </div>
</div>

						</div>
						<div class="modal-footer">
                        <div class="control-group">
  <div class="controls">
    <button id="Opslaan" name="Opslaan" class="btn btn-primary">Sla de wijzigingen op</button>
  </div>
</div>

						</div>
				</div>
		</div>
</div>

<script>
$(document).ready(function(){
	$('#beheerOpen').click(function(){
		$("#leden").load("/beheer/leden");
		$("#evenementen").load("/beheer/evenementen");
		$("#nieuws").load("/beheer/nieuws");
	});
});
</script>
<? }?>
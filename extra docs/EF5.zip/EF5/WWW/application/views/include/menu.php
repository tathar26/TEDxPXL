
<div class="row">
  <div class="col-md-2" style="text-align:center">
      <img src="/assets/img/logo.png" width="100" class="hidden-xs hidden-sm" alt="logo" />
  </div>
  <div class="col-md-10">
  	<?=$login ?>
    <div class="row">
      <div class="navbar navbar-default" role="navigation">
        <div class="navbar-header"> <a class="navbar-brand visible-xs visible-sm">Hexion</a>
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
          	<?php foreach($items as $item){ ?>
            <li class="<?=$item['active'] ?>"><a href="<?php echo base_url($item['controller']) ?>"><?=$item['item'] ?></a></li>
            <?php } ?>
            
          </ul>
          <div class="nav navbar-nav navbar-right col-md-3">
            <form class="navbar-form navbar-left hidden-xs hidden-sm" role="search" action="<?php echo base_url('zoek') ?>" method="post">
              <div class="input-group">
                <input type="text" class="form-control" id="search" name="search" placeholder="Zoek">
                <span class="input-group-btn">
                <button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search"></span></button>
                </span> </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

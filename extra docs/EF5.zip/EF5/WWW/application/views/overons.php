<div class="row">
  <div class="col-xs-12 col-md-8">
    <div class="jumbotron">
      <div class="panel-group" id="accordion">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#OverOns"> Over ons </a> </h4>
          </div>
          <div id="OverOns" class="panel-collapse collapse">
            <div class="panel-body">
              <div class="row">
                <div class="col-md-4" style="text-align:center">
                    <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRbezqZpEuwGSvitKy3wrwnth5kysKdRqBW54cAszm_wiutku3R"  width="140"  alt="foto" height="140" class="img-circle">
                    <h4>Joe Sixpack</h4>
                    <p>functie</p>
                  
                </div>
                <div class="col-md-4" style="text-align:center">
                    <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRbezqZpEuwGSvitKy3wrwnth5kysKdRqBW54cAszm_wiutku3R"  width="140"  alt="foto" height="140" class="img-circle">
                    <h4>Joe Sixpack</h4>
                    <p>functie</p>
                  </div>
                <div class="col-md-4" style="text-align:center">
                    <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRbezqZpEuwGSvitKy3wrwnth5kysKdRqBW54cAszm_wiutku3R"  width="140"  alt="foto" height="140" class="img-circle">
                    <h4>Joe Sixpack</h4>
                    <p>functie</p>
                  </div>
              </div>
              <div class="row">
                <div class="col-md-4" style="text-align:center">
                    <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRbezqZpEuwGSvitKy3wrwnth5kysKdRqBW54cAszm_wiutku3R"  width="140"  alt="foto" height="140" class="img-circle">
                    <h4>Joe Sixpack</h4>
                    <p>functie</p>
                  </div>
                <div class="col-md-4" style="text-align:center">
                    <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRbezqZpEuwGSvitKy3wrwnth5kysKdRqBW54cAszm_wiutku3R"  width="140"  alt="foto" height="140" class="img-circle">
                    <h4>Joe Sixpack</h4>
                    <p>functie</p>
                  </div>
                <div class="col-md-4" style="text-align:center">
                    <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRbezqZpEuwGSvitKy3wrwnth5kysKdRqBW54cAszm_wiutku3R"  width="140"  alt="foto" height="140" class="img-circle">
                    <h4>Joe Sixpack</h4>
                    <p>functie</p>
                  </div>
              </div>
              <div class="row">
                <div class="col-md-4" style="text-align:center">
                    <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRbezqZpEuwGSvitKy3wrwnth5kysKdRqBW54cAszm_wiutku3R"  width="140"  alt="foto" height="140" class="img-circle">
                    <h4>Joe Sixpack</h4>
                    <p>functie</p>
                  </div>
                <div class="col-md-4" style="text-align:center">
                    <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRbezqZpEuwGSvitKy3wrwnth5kysKdRqBW54cAszm_wiutku3R"  width="140"  alt="foto" height="140" class="img-circle">
                    <h4>Joe Sixpack</h4>
                    <p>functie</p>
                  </div>
                <div class="col-md-4" style="text-align:center">
                    <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRbezqZpEuwGSvitKy3wrwnth5kysKdRqBW54cAszm_wiutku3R"  width="140"  alt="foto" height="140" class="img-circle">
                    <h4>Joe Sixpack</h4>
                    <p>functie</p>
                  </div>
              </div>
            </div>
          </div>
        </div>
        <div class="panel panel-default">
          <div class="panel-heading">
            <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#LidWorden"> Lid worden? </a> </h4>
          </div>
          <div id="LidWorden" class="panel-collapse collapse">
            <div class="panel-body"> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS. </div>
            <div class="panel-footer" style="text-align:center">
            <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#lidModal">!! NU LID WORDEN !!</button>
            </div>
          </div>
        </div>
        <div class="panel panel-default">
          <div class="panel-heading">
            <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#OnzeLeden"> Onze Leden </a> </h4>
          </div>
          <div id="OnzeLeden" class="panel-collapse collapse">
            <div class="panel-body"> 
            <div class="row"> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS. </div>
          </div>
          <div class="row">
          test
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-xs-12 col-md-4">
    <div class="jumbotron">
      <h3>Ons Lied!</h3>
      <p><a>download het lied</a></p>
    </div>
  </div>
</div>
        <?php echo form_open("profiel/create");?>

<div class="modal fade" id="lidModal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="width:300px">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Registratie Lid</h4>
      </div>
      <div class="modal-body">
      <p>
            <?php echo lang('create_user_fname_label', 'username');?> <br />
            <?php echo form_input($username);?>
      </p>

      <p>
            <?php echo lang('create_user_fname_label', 'first_name');?> <br />
            <?php echo form_input($first_name);?>
      </p>

      <p>
            <?php echo lang('create_user_lname_label', 'last_name');?> <br />
            <?php echo form_input($last_name);?>
      </p>

      <p>
            <?php echo lang('create_user_email_label', 'email');?> <br />
            <?php echo form_input($email);?>
      </p>

      <p>
            <?php echo lang('create_user_password_label', 'password');?> <br />
            <?php echo form_input($password);?>
      </p>

      <p>
            <?php echo lang('create_user_password_confirm_label', 'password_confirm');?> <br />
            <?php echo form_input($password_confirm);?>
      </p>

      </div>
      <div class="modal-footer">
 		<button type="submit" id="submit" class="btn btn-primary">Registreer</button>  </p>
      </div>
    </div>
  </div>
</div>
<?php echo form_close();?>


<script>
$(document).ready(function() {
    var anchor = window.location.hash.replace("#", "");
    $(".collapse").collapse('hide');
    $("#" + anchor).collapse('show');
});
</script>
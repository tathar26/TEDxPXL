<div class="row">
  <div class="col-xs-12 col-md-3">
    <div class="row">
      <div class="panel panel-default" >
        <div class="panel-heading">
        <div class="input-group">
  				<span class="input-group-addon"><span class="glyphicon glyphicon-search"></span></span>
              <input type="text" id="form_zoek" class="form-control" placeholder="Zoek">
 			</div>
        </div>
          <ul class="list-group" id="forum_items" style="height:460px; overflow:scroll">
          </ul>
      </div>
      <br />
    </div>
  </div>
  <div class="col-xs-12 col-md-9" >
    <div class="panel panel-default" >
      <div class="panel-heading"> <div id="forum_item_title" class="pull-left" style="font-size:20px"> Welkom op het forum </div><?php if($active==1){ ?><button type="button" class="btn btn-default pull-right" data-toggle="modal" data-target="#add_topic"> <span class="glyphicon glyphicon-plus"></span> nieuw topic</button><?php } ?><div class="clearfix"></div></div>
      <ul id="reactions" class="list-group" style="height:404px; overflow:scroll">
      </ul>
      <div class="panel-footer">
        <div class="row">
        <?php if($active==1){ ?>

          <form action="http://www.artmex.be/forum/newComment" id="postComment" method="post">
            <div class="input-group">
              <input type="text" class="form-control" placeholder="Reactie" id="content" name="content">
              <span class="input-group-btn">
              <button type="submit"  class="btn btn-default"> <span class="glyphicon glyphicon-pencil"> Reageer!</span></button>
              </span> </div>
          </form>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php if($active==1){ ?>

<div class="modal fade" id="edit_comment">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Aanpassen</h4>
      </div>
      <div class="modal-body">
            <input type="text" class="form-control" id="editInput">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="editSave">Wijzig</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div class="modal fade" id="add_topic">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Nieuw Topic</h4>
      </div>
      <div class="modal-body">
            <input type="text" class="form-control" id="newTitle" placeholder="Titel"><br />
            <input type="text" class="form-control" id="newContent" placeholder="Inhoud">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="new">Aanmaken</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<?php } ?>

<script>

var contentId = <?=$current?>;
var itemEdit = 0;
var currentUser = <?=$currentUser?>;
var admin = <?=$admin?>;

height = $('#reactions').height();

if(contentId != 0){
	loadContent();
}

//Load Content
$( document ).ready(function() {
	$.getJSON( "<?php echo base_url('forum/getItems')?>", function( data ) {
	  $.each( data, function() {
		  $('#forum_items').append("<li class='forumItem list-group-item' id='forum_"+this.id+"'><h4 class='list-group-item-heading'>"+this.title+"</h4><p class='list-group-item-text'><i>"+this.first_name+"</i>: "+this.content+"</p></li>");
	  });
	});
});
//item inladen
$(document).on('click', '.forumItem', function(){
	$('.forumItem').removeClass('active');
	$(this).addClass('active');
	var title = $(this).find("h4").html();
	contentId = $(this).attr('id').substring(6);
	$('#forum_item_title').html(title);
	loadContent();
});

//item del
$(document).on('click', '.del', function(){
	var deleteItem = $(this).attr('id').substring(4);
	$.getJSON( "<?php echo base_url('forum/delComment/')?>"+deleteItem);
	$('#item_'+deleteItem).hide();
});

//item edit
$(document).on('click', '.ed', function(){
	var content = $(this).parentsUntil( ".list-group-item" ).find(".comment-text").html();
	itemEdit = $(this).attr('id').substring(3);
	$('#editInput').val(content);
	$('#edit_comment').modal();
});

//item edit save
$(document).on('click', '#editSave', function(){
	var newContent = $('#editInput').val();
	$.post("<?php echo base_url('forum/editComment') ?>", { itemId: itemEdit, content: newContent } );
	$('#edit_comment').modal('hide');
	loadContent();
});

//new Topic
$(document).on('click', '#new', function(){
	var content = $('#newContent').val();
	var title = $('#newTitle').val();
	$('#add_topic').modal('hide');
	$.post("<?php echo base_url('forum/newTopic') ?>", { title: title, content: content }, function(data){ 
		contentId = data.id; 	
		loadContent(); 
		var title = $("#forum_item_title").html(title);
		$('#forum_items').html("");
	$.getJSON( "<?php echo base_url('forum/getItems')?>", function( data ) {
	  $.each( data, function() {
		  if(this.id == contentId){
		  	$('#forum_items').append("<li class='forumItem list-group-item active' id='forum_"+this.id+"'><h4 class='list-group-item-heading'>"+this.title+"</h4><p class='list-group-item-text'><i>"+this.first_name+"</i>: "+this.content+"</p></li>");
		  }else{
		  	$('#forum_items').append("<li class='forumItem list-group-item' id='forum_"+this.id+"'><h4 class='list-group-item-heading'>"+this.title+"</h4><p class='list-group-item-text'><i>"+this.first_name+"</i>: "+this.content+"</p></li>");
		  }
	  });
	});
	}, "json");
});


//reactie toevoegen
$('#postComment').submit(function(){
	var postData = $( "#postComment" ).serialize();
	postData += "&item=" + encodeURIComponent(contentId);	
	$.post( "<?php echo base_url('forum/newComment') ?>", postData );
   $("#reactions").scrollTop($("#reactions")[0].scrollHeight);
	event.preventDefault();
	$('#content').val('');
	loadContent();
});

//zoeken
$( "#form_zoek" ).bind("change paste keyup", function() {
	var query = $('#form_zoek').val();
	$.post( "<?php echo base_url('forum/searchItems') ?>", { search: query }, function( data ) {
		$('#forum_items').html("");
	  $.each( data, function() {
		  if(this.id == contentId){
		  	$('#forum_items').append("<li class='forumItem list-group-item active' id='forum_"+this.id+"'><h4 class='list-group-item-heading'>"+this.title+"</h4><p class='list-group-item-text'><i>"+this.first_name+"</i>: "+this.content+"</p></li>");
		  }else{
		  	$('#forum_items').append("<li class='forumItem list-group-item' id='forum_"+this.id+"'><h4 class='list-group-item-heading'>"+this.title+"</h4><p class='list-group-item-text'><i>"+this.first_name+"</i>: "+this.content+"</p></li>");
		  }
	  });
	});

});


function loadContent(){
	$('#reactions').html("");

	$.getJSON( "<?php echo base_url('forum/getContent/')?>"+contentId, function( data ) {
		if(data.error){
			$('#reactions').html("<div class='alert alert-info'>"+data.error+"</div>");
		}else{
			  $.each( data, function() {
				  
				  var newContent = "<li class='list-group-item' id='item_"+this.id+"'><div class='row'><div class='col-xs-2 col-md-1'> <img src='"+this.userimg+"' class='img-circle img-responsive' alt='' /></div><div class='col-xs-8 col-md-10'><div><div class='mic-info'><strong>"+this.first_name+" "+this.last_name+"</strong>  op "+this.time+" </div></div><div class='comment-text'> "+this.content+"</div></div><div class='col-xs-2 col-md-1'>";
				  if(this.userID == currentUser || admin ==1){
				  newContent += "<button type='button' class='ed btn btn-primary btn-xs' id='ed_"+this.id+"' title='Edit'> <span class='glyphicon glyphicon-pencil'></span> </button> <button type='button' class='del btn btn-danger btn-xs' id='del_"+this.id+"' title='Delete'> <span class='glyphicon glyphicon-trash'></span></button>";
				  }
				  newContent += "</div></div></li>";
		
				  $('#reactions').append(newContent);
			  });
			  
			      $('#reactions').animate({scrollTop: height}, 0);
    			   height += $('#reactions').height();

		}
	});
}
</script> 

<div class="row">
  <div class="col-md-9"> <img src="<?php echo $eventImg; ?>" style="width:100%" alt="affiche"> <br/>
  </div>
  <div class="col-md-3">
    <div class="row">
      <iframe class="col-md-12" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.be/maps?f=q&amp;source=s_q&amp;hl=nl&amp;geocode=&amp;q=<?php echo $eventLat; ?>,+<?php echo $eventLong; ?>&amp;output=embed"></iframe>
      <br />
      <br />
      <div style="text-align:center">
  <p><?php echo $eventLoc; ?><br/>
    <?php echo $eventStr; ?> <br/>
    <?php echo $eventZp; ?>, <?php echo $eventCt; ?> <br/>
</div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-9">
    <h1><?php echo $eventName; ?></h1>
    <p><?php echo $eventDesc; ?></p>
  </div>
  <div class="col-md-3">
  <div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title pull-left" style="font-size:20px; margin-top:5px">Gaan</h3>
    <div class="pull-right" >
    <!--<button type="button" class="btn btn-info">Ik ga ook</button>-->
    </div>
    <div class="clearfix"></div>
  </div>
  <div class="panel-body">
      <?php foreach($going as $user){ ?>
  	<img data-toggle="tooltip" data-placement="top" title="<?=$user['name']?>" src="http://graph.facebook.com/<?=$user['id']?>/picture">
  <? } ?>
  </div>
  <div class="panel-footer" style="text-align:right">
  <a href="http://facebook.com/<?=$eventid; ?>">en <?=$goingCount; ?> anderen...</a>
  </div>
</div>

  </div>
</div>

SETUP hexion website: EF5
=========================

1. Importeer database mbv EF5.sql
2. Pas de base_url & cdn_url aan in /application/config/config.php
3. Pas /application/config/database.php aan met jouw logingevens.
4. Pas /application/config/facebook.php aan: http://developers.facebook.com
	-> ALS DEMO WORD ER DE PAGINA VAN CLUBVERSUZ GEBRUIKT.
5. Pas /application/config/contact.php aan met jouw contactemailadress.

LOGIN
=====
DEMO ADMIN ACCOUNT:
EMAIL: admin@admin
PASS: admin

FACEBOOK
========
Enkele delen van de site zullen niet ofline werken.
Voor online versie: http://www.artmex.be
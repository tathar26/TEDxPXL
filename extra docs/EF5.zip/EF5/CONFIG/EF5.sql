-- phpMyAdmin SQL Dump
-- version 3.5.8.1
-- http://www.phpmyadmin.net
--
-- Host: 10.246.16.217:3306
-- Generation Time: Feb 15, 2014 at 10:37 PM
-- Server version: 5.1.72-2
-- PHP Version: 5.3.3-7+squeeze15

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `artmex_be`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date` int(11) NOT NULL,
  `end` int(11) NOT NULL,
  `location` varchar(255) NOT NULL,
  `location_nr` int(11) NOT NULL,
  `location_zip` int(11) NOT NULL,
  `location_city` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `forum_item`
--

CREATE TABLE IF NOT EXISTS `forum_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `creator` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `forum_item`
--

INSERT INTO `forum_item` (`id`, `title`, `creator`, `time`) VALUES
(1, 'Examenvragen', 7, 1392277976),
(2, 'Hete Wijven!', 15, 1392288424),
(6, 'WELKOM HET WERKT!', 7, 1392497191),
(9, 'testen', 7, 1392497349),
(11, ':)', 29, 1392500348);

-- --------------------------------------------------------

--
-- Table structure for table `forum_reaction`
--

CREATE TABLE IF NOT EXISTS `forum_reaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `forum_reaction`
--

INSERT INTO `forum_reaction` (`id`, `item_id`, `user`, `time`, `content`) VALUES
(1, 1, 7, 1392277976, ' Waar kan ik examenvragen vinden?'),
(2, 2, 12, 1392288424, 'Hoe hebben we da op PXL ?'),
(64, 1, 7, 1392501696, 'Nu kunenn we beginnen leren ;)'),
(55, 0, 7, 1392496732, 'als dit er staat werkt het!'),
(56, 0, 7, 1392496847, 'als dit er staat proficiat'),
(63, 11, 29, 1392500348, 'lol'),
(61, 9, 7, 1392497349, ' Als dit er staat werkt dit he :P Juppii'),
(17, 2, 7, 1392314998, 'not ineressed'),
(18, 2, 7, 1392315324, ':)'),
(46, 1, 15, 1392332524, ' lol ? trololol'),
(45, 2, 7, 1392330807, '-.-'),
(43, 2, 15, 1392329701, ' testi'),
(44, 1, 12, 1392330699, 'c://PXLExamens/2TIN/2TINe/'),
(65, 1, 12, 1392501702, 'graag gedaan xD'),
(47, 1, 7, 1392413105, 'tnx glenn :)'),
(40, 1, 7, 1392317535, 'Alex share?');

-- --------------------------------------------------------

--
-- Table structure for table `going`
--

CREATE TABLE IF NOT EXISTS `going` (
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(80) NOT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `fb` varchar(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `fb`) VALUES
(24, 'T��&', 'admin admin', '7aecbf696d5287e9ecb2b69c391160b817f363c3', NULL, 'admin@admin', NULL, NULL, NULL, NULL, 1392476218, 1392503640, 1, 'admin', 'admin', NULL, NULL, ''),
(12, 'T��"', 'glenn.haesevoets', '8be3fa9adbd6644e77ee340e58aa43e15a5642dd', NULL, 'punkerbruin@live.be', NULL, NULL, NULL, NULL, 1392503764, 1392503764, 0, 'Glenn', 'Haesevoets', NULL, NULL, '1611745592'),
(7, 'T��&', 'feelitloveit', 'ec9478f85d04a6ceebfd1f30c510367a63c0b471', NULL, 'gunther@livezone.be', NULL, NULL, NULL, NULL, 1392503680, 1392503778, 1, 'Gunther', 'Claes', NULL, NULL, '1609381534');

-- --------------------------------------------------------

--
-- Table structure for table `users_details`
--

CREATE TABLE IF NOT EXISTS `users_details` (
  `user_id` int(11) NOT NULL,
  `user_address` varchar(40) DEFAULT NULL,
  `user_address_nr` int(11) DEFAULT NULL,
  `user_address_zip` int(11) DEFAULT NULL,
  `user_address_city` varchar(20) DEFAULT NULL,
  `user_date` int(11) DEFAULT NULL,
  `user_class` varchar(7) DEFAULT NULL,
  `user_phone` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_details`
--

INSERT INTO `users_details` (`user_id`, `user_address`, `user_address_nr`, `user_address_zip`, `user_address_city`, `user_date`, `user_class`, `user_phone`) VALUES
(12, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE IF NOT EXISTS `users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_users1_idx` (`user_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2432 ;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(2431, 0, 2),
(24, 24, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
